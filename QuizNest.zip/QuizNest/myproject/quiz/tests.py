from django.test import TestCase
from .models import MyModel

class MyModelTestCase(TestCase):
    def setUp(self):
        # Create test data here
        MyModel.objects.create(name="Test Object")

    def test_mymodel_name(self):
        # Fetch the object from the database
        obj = MyModel.objects.get(name="Test Object")
        
        # Test if the name of the object is correct
        self.assertEqual(obj.name, "Test Object")
