from django import forms

class NameForm(forms.Form):
    name = forms.CharField(label='What is your name?', max_length=100)
    user_id = forms.CharField(max_length=50, required=True)
    email = forms.EmailField(required=True)

class QuizForm(forms.Form):
    QUESTIONS = {
        1: {
            'label': "Which country has the largest land area in the world?", 
            'choices': [('a', 'USA'), ('b', 'China'), ('c', 'Russia'), ('d', 'Canada')]
        },
        2: {
            'label': "Which city serves as the headquarters of the United Nations?", 
            'choices': [('a', 'Washington, D.C.'), ('b', 'New York City'), ('c', 'Geneva'), ('d', 'Brussels')]
        },
        3: {
            'label': "Which country recently left the European Union in 2020?", 
            'choices': [('a', 'France'), ('b', 'Italy'), ('c', 'United Kingdom'), ('d', 'Germany')]
        },
        4: {
            'label': "What is the name of the military alliance led by the United States?", 
            'choices': [('a', 'EU'), ('b', 'NATO'), ('c', 'ASEAN'), ('d', 'OPEC')]
        },
        5: {
            'label': "Which two countries are involved in the ongoing dispute over Taiwan?", 
            'choices': [('a', 'USA and Japan'), ('b', 'China and Taiwan'), ('c', 'Russia and China'), ('d', 'India and Taiwan')]
        },
        6: {
            'label': "Which Middle Eastern country is known for its long-standing conflict with Israel?", 
            'choices': [('a', 'Saudi Arabia'), ('b', 'Iran'), ('c', 'Palestine'), ('d', 'Syria')]
        },
        7: {
            'label': "Which country is known as the 'Land of the Rising Sun'?", 
            'choices': [('a', 'China'), ('b', 'South Korea'), ('c', 'Japan'), ('d', 'Vietnam')]
        },
        8: {
            'label': "Which international organization works to maintain global peace and security?", 
            'choices': [('a', 'WHO'), ('b', 'IMF'), ('c', 'UN'), ('d', 'WTO')]
        },
        9: {
            'label': "Which country is the largest economy in the world?", 
            'choices': [('a', 'China'), ('b', 'USA'), ('c', 'Germany'), ('d', 'India')]
        },
        10: {
            'label': "What is the capital of the European Union?", 
            'choices': [('a', 'Brussels'), ('b', 'Berlin'), ('c', 'Paris'), ('d', 'London')]
        },
        11: {
            'label': "Which African country was never colonized?", 
            'choices': [('a', 'Nigeria'), ('b', 'Ethiopia'), ('c', 'Kenya'), ('d', 'South Africa')]
        },
        12: {
            'label': "Which country has the most nuclear weapons?", 
            'choices': [('a', 'China'), ('b', 'Russia'), ('c', 'USA'), ('d', 'North Korea')]
        },
        13: {
            'label': "Which country is known for the Great Wall?", 
            'choices': [('a', 'Japan'), ('b', 'Mongolia'), ('c', 'China'), ('d', 'India')]
        },
        14: {
            'label': "Which country recently invaded Ukraine in 2022?", 
            'choices': [('a', 'USA'), ('b', 'Russia'), ('c', 'China'), ('d', 'Germany')]
        },
        15: {
            'label': "Which country has the highest population?", 
            'choices': [('a', 'USA'), ('b', 'India'), ('c', 'China'), ('d', 'Brazil')]
        }
    }



    def __init__(self, *args, current_question=None, **kwargs):
        super().__init__(*args, **kwargs)
        if current_question and current_question in self.QUESTIONS:
            question_data = self.QUESTIONS[current_question]
            self.fields[f'q{current_question}'] = forms.ChoiceField(
                label=question_data['label'],
                choices=question_data['choices'],
                widget=forms.RadioSelect
            )
